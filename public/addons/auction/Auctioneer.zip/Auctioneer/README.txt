Auctioneer	3.6.1 (Platypus)
$Id: README.txt 656 2005-12-26 22:09:20Z mentalpower $
-------------------------------
FROM: http://auctioneeraddon.com/

