if (GetLocale() == "deDE") then

AtlasLootWBBossButtons = {
    Kazzak = {
       "KKazzak";
       };

    FourDragons = {
       "DLethon";
       "DEmeriss";
       "DTaerar";
       "DYsondre";
       };
    Azuregos = {
       "AAzuregos";
       };
    };

end

