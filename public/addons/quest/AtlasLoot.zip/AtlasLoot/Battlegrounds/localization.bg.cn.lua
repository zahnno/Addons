﻿-- [[
-- Version: 1.17.03
-- Last Updated: 2006/08/02
-- ]]
if (GetLocale() == "zhCN") then

------------
-- 输出 --
------------
AtlasLootBattlegrounds = {

    AlteracValleyNorth = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "AVFriendly";
        "AVHonored";
        "AVRevered";
        "AVExalted";
        "PVPSET";
    };
    
    AlteracValleySouth = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "AVFriendly";
        "AVHonored";
        "AVRevered";
        "AVExalted";
        "PVPSET";
    };
    
    ArathiBasin = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "ABFriendly";
        "ABHonored";
        "ABRevered";
        "ABExalted";
        "PVPSET";
    };
    
    WarsongGulch = {
        "";
        "";
        "";
        "WSGFriendly";
        "WSGHonored";
        "WSGRevered";
        "WSGExalted";
        "PVPSET";
    };
};

end
