
if not QuestieConfig then QuestieConfig = {

	-- tracker
	['AlwaysShowDistance'] = false,
	['AlwaysShowLevel'] = true,
	['ArrowEnabled'] = true,

} end